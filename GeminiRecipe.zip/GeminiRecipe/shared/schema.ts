import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User profiles with anonymous nicknames
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nickname: text("nickname").notNull(),
  language: text("language").notNull().default("english"),
  joinedAt: timestamp("joined_at").defaultNow(),
});

// Chat messages with AI
export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  content: text("content").notNull(),
  role: text("role").notNull(), // "user" | "assistant"
  timestamp: timestamp("timestamp").defaultNow(),
});

// Counselor profiles and sessions
export const counselors = pgTable("counselors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  specialization: text("specialization").notNull(),
  experience: text("experience").notNull(),
  languages: text("languages").array().notNull(),
  bio: text("bio").notNull(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  counselorId: varchar("counselor_id").notNull(),
  scheduledTime: timestamp("scheduled_time").notNull(),
  nickname: text("nickname").notNull(),
  reason: text("reason"),
  status: text("status").notNull().default("scheduled"), // "scheduled" | "completed" | "cancelled"
  createdAt: timestamp("created_at").defaultNow(),
});

// Forum posts and moderation
export const forumPosts = pgTable("forum_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  nickname: text("nickname").notNull(),
  topic: text("topic").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  likes: integer("likes").notNull().default(0),
  replies: integer("replies").notNull().default(0),
  flagged: boolean("flagged").notNull().default(false),
  approved: boolean("approved").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Mood tracking
export const moodEntries = pgTable("mood_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  stressLevel: integer("stress_level").notNull(), // 1-10
  anxietyLevel: integer("anxiety_level").notNull(), // 1-10
  moodLevel: integer("mood_level").notNull(), // 1-10
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  nickname: true,
  language: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  userId: true,
  content: true,
  role: true,
});

export const insertSessionSchema = createInsertSchema(sessions).pick({
  userId: true,
  counselorId: true,
  scheduledTime: true,
  nickname: true,
  reason: true,
});

export const insertForumPostSchema = createInsertSchema(forumPosts).pick({
  userId: true,
  nickname: true,
  topic: true,
  title: true,
  content: true,
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).pick({
  userId: true,
  stressLevel: true,
  anxietyLevel: true,
  moodLevel: true,
  notes: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

export type Counselor = typeof counselors.$inferSelect;

export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;

export type ForumPost = typeof forumPosts.$inferSelect;
export type InsertForumPost = z.infer<typeof insertForumPostSchema>;

export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
