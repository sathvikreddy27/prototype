import { useState } from "react"
import { Book, Video, Headphones, Globe, ChevronRight, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import anxietyImage from "@assets/generated_images/Anxiety_support_illustration_98670d12.png"

// Mock resource data - todo: remove mock functionality
const resourceCategories = [
  {
    id: "anxiety",
    title: "Anxiety Management",
    description: "Techniques and strategies to manage anxiety and panic",
    icon: Book,
    color: "bg-blue-100 text-blue-700",
    image: anxietyImage,
    resources: [
      {
        type: "article",
        title: "Understanding Anxiety: A Student's Guide",
        duration: "5 min read",
        description: "Learn about different types of anxiety and how they affect students."
      },
      {
        type: "video",
        title: "Breathing Techniques for Panic Attacks",
        duration: "3 min watch",
        description: "Quick breathing exercises to manage panic attacks."
      },
      {
        type: "audio",
        title: "Guided Anxiety Relief Meditation",
        duration: "10 min audio",
        description: "Calming meditation specifically designed for anxiety relief."
      }
    ]
  },
  {
    id: "stress",
    title: "Stress Management",
    description: "Tools to handle academic and personal stress",
    icon: Video,
    color: "bg-green-100 text-green-700",
    resources: [
      {
        type: "article",
        title: "Time Management for Students",
        duration: "7 min read",
        description: "Effective strategies to manage study time and reduce stress."
      },
      {
        type: "video",
        title: "Progressive Muscle Relaxation",
        duration: "8 min watch",
        description: "Learn to release physical tension and stress."
      },
      {
        type: "audio",
        title: "Study Break Meditation",
        duration: "5 min audio",
        description: "Quick reset for between study sessions."
      }
    ]
  },
  {
    id: "sleep",
    title: "Sleep & Rest",
    description: "Improve sleep quality and establish healthy routines",
    icon: Headphones,
    color: "bg-purple-100 text-purple-700",
    resources: [
      {
        type: "article",
        title: "Sleep Hygiene for Better Rest",
        duration: "6 min read",
        description: "Create the perfect environment for quality sleep."
      },
      {
        type: "video",
        title: "Bedtime Yoga Routine",
        duration: "12 min watch",
        description: "Gentle yoga to prepare your body for sleep."
      },
      {
        type: "audio",
        title: "Sleep Stories for Students",
        duration: "15 min audio",
        description: "Calming stories to help you drift off to sleep."
      }
    ]
  },
  {
    id: "exam",
    title: "Exam Preparation",
    description: "Overcome test anxiety and improve performance",
    icon: Globe,
    color: "bg-orange-100 text-orange-700",
    resources: [
      {
        type: "article",
        title: "Beating Test Anxiety",
        duration: "4 min read",
        description: "Strategies to stay calm and focused during exams."
      },
      {
        type: "video",
        title: "Study Techniques That Work",
        duration: "6 min watch",
        description: "Evidence-based methods to improve retention."
      },
      {
        type: "audio",
        title: "Pre-Exam Confidence Meditation",
        duration: "8 min audio",
        description: "Build confidence before important tests."
      }
    ]
  }
]

const resourceTypeIcons = {
  article: Book,
  video: Video,
  audio: Headphones
}

export default function ResourcesPage() {
  const [language, setLanguage] = useState("english")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  if (selectedCategory) {
    const category = resourceCategories.find(c => c.id === selectedCategory)
    if (!category) return null

    return (
      <div className="p-6 space-y-6">
        {/* Back Navigation */}
        <Button
          variant="ghost"
          onClick={() => setSelectedCategory(null)}
          data-testid="button-back-to-categories"
        >
          ← Back to Categories
        </Button>

        {/* Category Header */}
        <div className="text-center space-y-4">
          <div className={`w-16 h-16 rounded-full ${category.color} flex items-center justify-center mx-auto`}>
            <category.icon className="h-8 w-8" />
          </div>
          <h1 className="text-3xl font-bold font-serif">{category.title}</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {category.description}
          </p>
        </div>

        {/* Resources List */}
        <div className="max-w-4xl mx-auto space-y-4">
          {category.resources.map((resource, index) => {
            const IconComponent = resourceTypeIcons[resource.type as keyof typeof resourceTypeIcons]
            return (
              <Card key={index} className="hover-elevate cursor-pointer" data-testid={`card-resource-${index}`}>
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-accent/20 rounded-lg">
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-lg">{resource.title}</CardTitle>
                        <Badge variant="secondary">{resource.duration}</Badge>
                      </div>
                      <CardDescription className="mt-2">
                        {resource.description}
                      </CardDescription>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </CardHeader>
              </Card>
            )
          })}
        </div>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold font-serif">Wellness Resources</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Evidence-based resources to support your mental health journey. 
          Choose from articles, videos, and guided audio content.
        </p>
      </div>

      {/* Language Toggle */}
      <div className="flex justify-center">
        <Tabs value={language} onValueChange={setLanguage}>
          <TabsList>
            <TabsTrigger value="english" data-testid="tab-english">English</TabsTrigger>
            <TabsTrigger value="hindi" data-testid="tab-hindi">हिंदी</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Categories Grid */}
      <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {resourceCategories.map((category) => (
          <Card 
            key={category.id}
            className="hover-elevate cursor-pointer transition-all"
            onClick={() => setSelectedCategory(category.id)}
            data-testid={`card-category-${category.id}`}
          >
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className={`p-4 rounded-full ${category.color}`}>
                  <category.icon className="h-6 w-6" />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-xl">{category.title}</CardTitle>
                  <CardDescription className="mt-2">
                    {category.description}
                  </CardDescription>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Badge variant="outline" className="text-xs">
                  <Book className="h-3 w-3 mr-1" />
                  Articles
                </Badge>
                <Badge variant="outline" className="text-xs">
                  <Video className="h-3 w-3 mr-1" />
                  Videos
                </Badge>
                <Badge variant="outline" className="text-xs">
                  <Headphones className="h-3 w-3 mr-1" />
                  Audio
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Featured Content */}
      <div className="max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4 font-serif">Featured This Week</h2>
        <Card className="hover-elevate">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-4 bg-primary/10 rounded-full">
                <Video className="h-8 w-8 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold">Mindfulness for Students</h3>
                <p className="text-muted-foreground mt-1">
                  A comprehensive guide to incorporating mindfulness into your daily routine
                </p>
                <Badge className="mt-2">15 min watch</Badge>
              </div>
              <Button data-testid="button-featured-content">
                Watch Now
                <ExternalLink className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}