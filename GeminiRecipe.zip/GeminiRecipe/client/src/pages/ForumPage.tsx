import { useState } from "react"
import { Heart, MessageSquare, Flag, Plus, ArrowUp, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Mock forum data - todo: remove mock functionality
const forumTopics = ["Exam Stress", "Sleep Hacks", "Feel-Good Wall", "Study Tips", "Anxiety Support"]

const mockPosts = [
  {
    id: "1",
    nickname: "StudyBuddy23",
    topic: "Exam Stress",
    title: "Anyone else feeling overwhelmed with finals?",
    content: "I have 4 exams next week and I'm barely keeping up. Any tips for staying focused?",
    timestamp: "2 hours ago",
    likes: 12,
    replies: 8,
    liked: false
  },
  {
    id: "2",
    nickname: "MindfulMaven",
    topic: "Feel-Good Wall",
    title: "Small win today 🎉",
    content: "Finally finished my research paper after weeks of procrastination. It's not perfect but I'm proud I pushed through!",
    timestamp: "4 hours ago",
    likes: 28,
    replies: 6,
    liked: true
  },
  {
    id: "3",
    nickname: "NightOwl",
    topic: "Sleep Hacks",
    title: "What helps you fall asleep when your mind is racing?",
    content: "I've been trying meditation apps but my thoughts keep spiraling about assignments. What works for you?",
    timestamp: "1 day ago",
    likes: 15,
    replies: 12,
    liked: false
  },
  {
    id: "4",
    nickname: "AnxietyWarrior",
    topic: "Anxiety Support",
    title: "Breathing technique that actually works",
    content: "Try the 4-7-8 method: breathe in for 4, hold for 7, out for 8. It's been a game-changer for my panic attacks.",
    timestamp: "1 day ago",
    likes: 34,
    replies: 9,
    liked: false
  }
]

interface NewPostForm {
  title: string
  content: string
  topic: string
  nickname: string
}

export default function ForumPage() {
  const [selectedTopic, setSelectedTopic] = useState("All")
  const [posts, setPosts] = useState(mockPosts)
  const [showNewPost, setShowNewPost] = useState(false)
  const [newPost, setNewPost] = useState<NewPostForm>({
    title: "",
    content: "",
    topic: forumTopics[0],
    nickname: ""
  })

  const filteredPosts = selectedTopic === "All" 
    ? posts 
    : posts.filter(post => post.topic === selectedTopic)

  const handleLike = (postId: string) => {
    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { 
            ...post, 
            liked: !post.liked,
            likes: post.liked ? post.likes - 1 : post.likes + 1
          }
        : post
    ))
  }

  const handleCreatePost = () => {
    if (!newPost.title || !newPost.content || !newPost.nickname) return

    const post = {
      id: Date.now().toString(),
      ...newPost,
      timestamp: "Just now",
      likes: 0,
      replies: 0,
      liked: false
    }

    setPosts(prev => [post, ...prev])
    setNewPost({ title: "", content: "", topic: forumTopics[0], nickname: "" })
    setShowNewPost(false)
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-serif">Peer Support Community</h1>
          <p className="text-muted-foreground mt-2">
            Connect anonymously with fellow students in a supportive environment
          </p>
        </div>
        <Dialog open={showNewPost} onOpenChange={setShowNewPost}>
          <DialogTrigger asChild>
            <Button data-testid="button-new-post">
              <Plus className="h-4 w-4 mr-2" />
              New Post
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Share with the Community</DialogTitle>
              <DialogDescription>
                Your post will be anonymous and moderated before appearing
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="post-nickname">Nickname</Label>
                <Input
                  id="post-nickname"
                  value={newPost.nickname}
                  onChange={(e) => setNewPost(prev => ({ ...prev, nickname: e.target.value }))}
                  placeholder="Choose an anonymous nickname"
                  data-testid="input-post-nickname"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="post-topic">Topic</Label>
                <select 
                  id="post-topic"
                  value={newPost.topic}
                  onChange={(e) => setNewPost(prev => ({ ...prev, topic: e.target.value }))}
                  className="w-full p-2 border rounded-md"
                  data-testid="select-post-topic"
                >
                  {forumTopics.map(topic => (
                    <option key={topic} value={topic}>{topic}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="post-title">Title</Label>
                <Input
                  id="post-title"
                  value={newPost.title}
                  onChange={(e) => setNewPost(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="What's on your mind?"
                  data-testid="input-post-title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="post-content">Content</Label>
                <Textarea
                  id="post-content"
                  value={newPost.content}
                  onChange={(e) => setNewPost(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Share your thoughts, ask for advice, or offer support..."
                  rows={4}
                  data-testid="textarea-post-content"
                />
              </div>
              <Button 
                onClick={handleCreatePost}
                disabled={!newPost.title || !newPost.content || !newPost.nickname}
                className="w-full"
                data-testid="button-submit-post"
              >
                Share Post
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Topic Filter */}
      <Tabs value={selectedTopic} onValueChange={setSelectedTopic}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="All" data-testid="tab-all">All</TabsTrigger>
          {forumTopics.map(topic => (
            <TabsTrigger 
              key={topic} 
              value={topic}
              data-testid={`tab-${topic.toLowerCase().replace(' ', '-')}`}
            >
              {topic}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {/* Posts */}
      <div className="space-y-4">
        {filteredPosts.map((post) => (
          <Card key={post.id} className="hover-elevate">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback>
                      <User className="h-5 w-5" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold">{post.nickname}</h3>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Badge variant="outline" className="text-xs">{post.topic}</Badge>
                      <span>•</span>
                      <span>{post.timestamp}</span>
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="sm" data-testid={`button-flag-${post.id}`}>
                  <Flag className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">{post.title}</h4>
                <p className="text-muted-foreground">{post.content}</p>
              </div>
              
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleLike(post.id)}
                  className={`gap-2 ${post.liked ? "text-red-500" : ""}`}
                  data-testid={`button-like-${post.id}`}
                >
                  <Heart className={`h-4 w-4 ${post.liked ? "fill-current" : ""}`} />
                  {post.likes}
                </Button>
                <Button variant="ghost" size="sm" className="gap-2" data-testid={`button-reply-${post.id}`}>
                  <MessageSquare className="h-4 w-4" />
                  {post.replies}
                </Button>
                <Button variant="ghost" size="sm" className="gap-2" data-testid={`button-share-${post.id}`}>
                  <ArrowUp className="h-4 w-4" />
                  Share
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Community Guidelines */}
      <Card className="bg-accent/20">
        <CardContent className="p-6">
          <h3 className="font-semibold mb-3">Community Guidelines</h3>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Be kind and supportive to fellow community members</li>
            <li>• Maintain anonymity - no personal information sharing</li>
            <li>• Report concerning content using the flag button</li>
            <li>• All posts are moderated before appearing publicly</li>
            <li>• Crisis situations should use emergency helplines</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}