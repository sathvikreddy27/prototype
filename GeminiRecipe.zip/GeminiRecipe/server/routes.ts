import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateMentalHealthResponse, type ChatMessage } from "./gemini";
import { z } from "zod";

// Simple in-memory rate limiting
const rateLimitMap = new Map<string, { count: number, resetTime: number }>();
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const RATE_LIMIT_MAX_REQUESTS = 20; // 20 requests per minute

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const userLimit = rateLimitMap.get(ip);
  
  if (!userLimit || now > userLimit.resetTime) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
    return true;
  }
  
  if (userLimit.count >= RATE_LIMIT_MAX_REQUESTS) {
    return false;
  }
  
  userLimit.count++;
  return true;
}

const chatRequestSchema = z.object({
  message: z.string().min(1).max(2000), // Limit message length
  conversationHistory: z.array(z.object({
    role: z.enum(["user", "assistant"]),
    content: z.string()
  })).max(10).optional() // Limit conversation history
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat endpoint for AI mental health support
  app.post("/api/chat", async (req, res) => {
    const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
    
    // Rate limiting check
    if (!checkRateLimit(clientIp)) {
      return res.status(429).json({ 
        error: "Rate limit exceeded",
        message: "You're reaching out frequently, which shows courage. Please take a moment to breathe, and if you're in crisis, contact a counselor immediately.",
        isCrisis: false
      });
    }

    try {
      const { message, conversationHistory } = chatRequestSchema.parse(req.body);
      
      const response = await generateMentalHealthResponse(message, conversationHistory);
      
      // Always return 200 with structured response for better UX
      res.json(response);
      
    } catch (error) {
      console.error("Chat API Error:", {
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString(),
        ip: clientIp
      });
      
      // Return structured 200 response even on error for better UX
      res.json({ 
        message: "I'm having trouble right now, but I'm here for you. If you're in crisis, please reach out to a counselor or crisis helpline immediately.",
        isCrisis: false
      });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  const httpServer = createServer(app);

  return httpServer;
}
