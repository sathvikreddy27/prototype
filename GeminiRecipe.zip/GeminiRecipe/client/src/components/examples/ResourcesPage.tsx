import ResourcesPage from '../../pages/ResourcesPage'

export default function ResourcesPageExample() {
  return (
    <div className="max-h-96 overflow-y-auto">
      <ResourcesPage />
    </div>
  )
}