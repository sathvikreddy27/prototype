# MindEase Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from Headspace (wellness), Calm (mental health), and Discord (community) for their empathetic, calming aesthetics while maintaining professional credibility for mental health services.

## Core Design Elements

### A. Color Palette
**Light Mode:**
- Primary: 220 15% 25% (Deep calming blue-gray)
- Secondary: 200 25% 85% (Soft light blue)
- Accent: 160 30% 70% (Gentle sage green)
- Background: 0 0% 98% (Warm white)
- Surface: 0 0% 100% (Pure white)

**Dark Mode:**
- Primary: 220 20% 80% (Light blue-gray)
- Secondary: 200 15% 20% (Dark blue surface)
- Accent: 160 25% 60% (Muted sage)
- Background: 220 15% 8% (Deep dark blue)
- Surface: 220 10% 12% (Elevated dark surface)

### B. Typography
**Fonts:** Inter (primary), Source Serif Pro (headings for warmth)
**Scale:** text-sm, text-base, text-lg, text-xl, text-2xl, text-3xl
**Weights:** font-normal (400), font-medium (500), font-semibold (600)

### C. Layout System
**Spacing Units:** Tailwind units of 2, 4, 6, 8, 12, 16
**Grid:** 12-column responsive grid with generous gutters
**Containers:** max-w-7xl for main content, max-w-md for forms

### D. Component Library

**Navigation:**
- Sticky header with subtle backdrop blur
- Bottom navigation for mobile with rounded pill indicators
- Breadcrumbs for deep navigation

**Cards:**
- Soft shadows (shadow-sm, shadow-lg)
- Rounded corners (rounded-xl, rounded-2xl)
- Gentle hover elevations

**Forms:**
- Floating labels with smooth transitions
- Soft focus states with colored borders
- Inline validation with gentle color feedback

**Chat Interface:**
- WhatsApp-inspired bubble design
- Typing indicators with animated dots
- Message timestamps in muted text

**Forum Components:**
- Thread cards with engagement metrics
- Anonymous avatar generation with soft colors
- Upvote buttons with heart animations

### E. Animations
Minimal and purposeful:
- Gentle page transitions (200ms ease-out)
- Smooth hover states on interactive elements
- Subtle loading states with breathing animations
- Crisis alert modal with gentle attention-drawing pulse

## Content Strategy
**Tone:** Empathetic, non-judgmental, professional yet approachable
**Imagery:** Abstract calming patterns, soft gradients, nature-inspired illustrations
**Iconography:** Rounded, friendly icons from Heroicons or Lucide

## Safety & Accessibility
- High contrast ratios (4.5:1 minimum)
- Clear crisis intervention CTAs with warm red accent (0 80% 60%)
- Consistent focus indicators across all interactive elements
- Screen reader friendly labels for all form inputs and buttons

## Key Experience Principles
1. **Calm First:** Every interaction should reduce anxiety, not increase it
2. **Privacy by Design:** Visual cues reinforcing anonymity and confidentiality
3. **Progressive Disclosure:** Reveal complexity gradually as users engage deeper
4. **Emotional Safety:** Warm, non-clinical aesthetic that feels supportive