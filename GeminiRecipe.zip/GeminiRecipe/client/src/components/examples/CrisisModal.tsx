import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { CrisisModal } from '../CrisisModal'

export default function CrisisModalExample() {
  const [open, setOpen] = useState(false)

  return (
    <div className="p-4">
      <Button onClick={() => setOpen(true)}>
        Show Crisis Modal
      </Button>
      <CrisisModal open={open} onOpenChange={setOpen} />
    </div>
  )
}