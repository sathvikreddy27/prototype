import { AlertTriangle, Phone, ExternalLink } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface CrisisModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const crisisHelplines = [
  {
    name: "KIRAN Mental Health Helpline",
    number: "1800-599-0019",
    description: "24/7 mental health support",
    website: "https://www.tiss.edu/kiran"
  },
  {
    name: "Snehi Helpline",
    number: "91-22-2772-6771",
    description: "Crisis intervention and suicide prevention",
    website: "https://snehi.org"
  },
  {
    name: "iCall Helpline",
    number: "91-22-2556-3291",
    description: "Psychosocial helpline",
    website: "https://icallhelpline.org"
  }
]

export function CrisisModal({ open, onOpenChange }: CrisisModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Crisis Support Available
          </DialogTitle>
          <DialogDescription>
            You don't have to go through this alone. Professional help is available 24/7.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="bg-destructive/10 p-4 rounded-lg border border-destructive/20">
            <p className="text-sm font-medium text-destructive mb-2">
              If you're having thoughts of self-harm or suicide, please reach out immediately:
            </p>
          </div>

          <div className="space-y-3">
            {crisisHelplines.map((helpline, index) => (
              <Card key={index} className="border-accent/50">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start gap-3">
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{helpline.name}</h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        {helpline.description}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        asChild
                        data-testid={`button-call-${index}`}
                      >
                        <a href={`tel:${helpline.number}`}>
                          <Phone className="h-3 w-3 mr-1" />
                          Call
                        </a>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        asChild
                        data-testid={`button-website-${index}`}
                      >
                        <a href={helpline.website} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      </Button>
                    </div>
                  </div>
                  <p className="text-sm font-mono mt-2 text-primary">
                    {helpline.number}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Button 
              variant="secondary" 
              onClick={() => onOpenChange(false)}
              data-testid="button-close-crisis-modal"
            >
              I'm feeling safer now
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}