import { useState } from "react"
import { Calendar, Clock, User, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import counselorWoman from "@assets/generated_images/Counselor_avatar_woman_a779dede.png"
import counselorMan from "@assets/generated_images/Counselor_avatar_man_84259d97.png"

// Mock counselor data - todo: remove mock functionality
const mockCounselors = [
  {
    id: "1",
    name: "Dr. Sarah Chen",
    specialization: "Anxiety & Stress Management",
    experience: "8 years",
    languages: ["English", "Hindi"],
    avatar: counselorWoman,
    bio: "Specializes in helping students manage academic stress and anxiety disorders.",
    availability: ["2024-01-15T10:00:00", "2024-01-15T14:00:00", "2024-01-16T09:00:00"]
  },
  {
    id: "2",
    name: "Dr. Raj Patel",
    specialization: "Depression & Mood Disorders",
    experience: "12 years",
    languages: ["English", "Hindi", "Gujarati"],
    avatar: counselorMan,
    bio: "Expert in cognitive behavioral therapy and mindfulness-based interventions.",
    availability: ["2024-01-15T11:00:00", "2024-01-15T15:00:00", "2024-01-17T10:00:00"]
  },
  {
    id: "3",
    name: "Dr. Priya Sharma",
    specialization: "Academic Stress & Performance",
    experience: "6 years",
    languages: ["English", "Hindi"],
    avatar: counselorWoman,
    bio: "Helps students overcome exam anxiety and improve academic performance.",
    availability: ["2024-01-16T10:00:00", "2024-01-16T16:00:00", "2024-01-17T14:00:00"]
  }
]

interface BookingFormData {
  nickname: string
  preferredTime: string
  reason: string
}

export default function BookingPage() {
  const [selectedCounselor, setSelectedCounselor] = useState<string | null>(null)
  const [selectedTime, setSelectedTime] = useState<string>("")
  const [bookingForm, setBookingForm] = useState<BookingFormData>({
    nickname: "",
    preferredTime: "",
    reason: ""
  })
  const [bookingConfirmed, setBookingConfirmed] = useState(false)

  const formatTimeSlot = (datetime: string) => {
    const date = new Date(datetime)
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  }

  const handleBookSession = () => {
    if (!selectedCounselor || !selectedTime || !bookingForm.nickname) return
    
    // Mock booking confirmation - todo: replace with real booking
    console.log("Booking session:", {
      counselor: selectedCounselor,
      time: selectedTime,
      ...bookingForm
    })
    
    setBookingConfirmed(true)
  }

  if (bookingConfirmed) {
    const counselor = mockCounselors.find(c => c.id === selectedCounselor)
    const timeSlot = formatTimeSlot(selectedTime)
    
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <Card className="text-center">
          <CardHeader>
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <CardTitle className="text-2xl font-serif">Session Booked Successfully!</CardTitle>
            <CardDescription>
              Your confidential session has been scheduled
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-accent/20 p-4 rounded-lg">
              <h3 className="font-semibold">Session Details</h3>
              <p className="text-sm text-muted-foreground mt-2">
                <strong>Counselor:</strong> {counselor?.name}<br />
                <strong>Date:</strong> {timeSlot.date}<br />
                <strong>Time:</strong> {timeSlot.time}<br />
                <strong>Your Nickname:</strong> {bookingForm.nickname}
              </p>
            </div>
            <p className="text-sm text-muted-foreground">
              You'll receive a reminder 24 hours before your session. 
              All sessions are completely confidential.
            </p>
            <Button 
              onClick={() => {
                setBookingConfirmed(false)
                setSelectedCounselor(null)
                setSelectedTime("")
                setBookingForm({ nickname: "", preferredTime: "", reason: "" })
              }}
              data-testid="button-book-another"
            >
              Book Another Session
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold font-serif mb-2">Book a Counseling Session</h1>
        <p className="text-muted-foreground">
          Connect with qualified mental health professionals. All sessions are completely confidential.
        </p>
      </div>

      {/* Counselor Selection */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Choose Your Counselor</h2>
        <div className="grid gap-4">
          {mockCounselors.map((counselor) => (
            <Card 
              key={counselor.id}
              className={`cursor-pointer transition-all hover-elevate ${
                selectedCounselor === counselor.id ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => setSelectedCounselor(counselor.id)}
              data-testid={`card-counselor-${counselor.id}`}
            >
              <CardHeader>
                <div className="flex items-start gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={counselor.avatar} alt={counselor.name} />
                    <AvatarFallback>
                      <User className="h-8 w-8" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-lg">{counselor.name}</CardTitle>
                    <CardDescription className="text-base font-medium text-primary">
                      {counselor.specialization}
                    </CardDescription>
                    <p className="text-sm text-muted-foreground mt-1">
                      {counselor.experience} experience
                    </p>
                    <div className="flex gap-1 mt-2">
                      {counselor.languages.map((lang) => (
                        <Badge key={lang} variant="secondary" className="text-xs">
                          {lang}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{counselor.bio}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Time Slot Selection */}
      {selectedCounselor && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Available Time Slots</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {mockCounselors
              .find(c => c.id === selectedCounselor)
              ?.availability.map((time) => {
                const slot = formatTimeSlot(time)
                return (
                  <Button
                    key={time}
                    variant={selectedTime === time ? "default" : "outline"}
                    className="p-4 h-auto flex flex-col items-center"
                    onClick={() => setSelectedTime(time)}
                    data-testid={`button-timeslot-${time}`}
                  >
                    <Calendar className="h-4 w-4 mb-1" />
                    <span className="font-medium">{slot.date}</span>
                    <span className="text-sm flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {slot.time}
                    </span>
                  </Button>
                )
              })}
          </div>
        </div>
      )}

      {/* Booking Form */}
      {selectedCounselor && selectedTime && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Session Details</h2>
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nickname">Preferred Nickname *</Label>
                <Input
                  id="nickname"
                  value={bookingForm.nickname}
                  onChange={(e) => setBookingForm(prev => ({ ...prev, nickname: e.target.value }))}
                  placeholder="How would you like to be addressed?"
                  data-testid="input-nickname"
                />
                <p className="text-xs text-muted-foreground">
                  No real names required - use any name you're comfortable with
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reason">What would you like to discuss? (Optional)</Label>
                <Input
                  id="reason"
                  value={bookingForm.reason}
                  onChange={(e) => setBookingForm(prev => ({ ...prev, reason: e.target.value }))}
                  placeholder="Brief description to help your counselor prepare"
                  data-testid="input-reason"
                />
              </div>

              <div className="bg-accent/20 p-4 rounded-lg">
                <h4 className="font-medium text-sm mb-2">Privacy Notice</h4>
                <p className="text-xs text-muted-foreground">
                  Your session is completely confidential. No personal information is required, 
                  and all communications are protected by professional ethics guidelines.
                </p>
              </div>

              <Button 
                onClick={handleBookSession}
                disabled={!bookingForm.nickname}
                className="w-full"
                data-testid="button-confirm-booking"
              >
                Confirm Session Booking
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}