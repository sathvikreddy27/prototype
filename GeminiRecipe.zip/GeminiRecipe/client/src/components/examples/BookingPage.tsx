import BookingPage from '../../pages/BookingPage'

export default function BookingPageExample() {
  return (
    <div className="max-h-96 overflow-y-auto">
      <BookingPage />
    </div>
  )
}