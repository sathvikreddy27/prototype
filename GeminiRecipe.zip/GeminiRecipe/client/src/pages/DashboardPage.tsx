import { TrendingUp, Users, Calendar, MessageSquare, AlertTriangle, CheckCircle } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

// Mock analytics data - todo: remove mock functionality
const analytics = {
  totalUsers: 1247,
  sessionsBooked: 89,
  activeForumPosts: 156,
  moodCheckins: 324,
  weeklyGrowth: 12,
  resourcesAccessed: 567
}

const moodTrends = [
  { week: "Week 1", stress: 65, anxiety: 58, mood: 42 },
  { week: "Week 2", stress: 62, anxiety: 55, mood: 48 },
  { week: "Week 3", stress: 58, anxiety: 52, mood: 52 },
  { week: "Week 4", stress: 55, anxiety: 48, mood: 58 }
]

const topResources = [
  { title: "Anxiety Management Guide", views: 234, category: "Anxiety" },
  { title: "Study Break Meditation", views: 189, category: "Stress" },
  { title: "Sleep Hygiene Tips", views: 167, category: "Sleep" },
  { title: "Exam Preparation Strategies", views: 156, category: "Academic" }
]

const flaggedContent = [
  {
    id: "1",
    type: "Forum Post",
    content: "Feeling really down lately and having dark thoughts...",
    author: "AnonymousUser123",
    flagReason: "Crisis language detected",
    status: "pending"
  },
  {
    id: "2",
    type: "Chat Message",
    content: "Everything feels hopeless right now",
    author: "ChatUser456",
    flagReason: "Potential self-harm indication",
    status: "reviewed"
  }
]

export default function DashboardPage() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold font-serif">Admin Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Platform analytics and content moderation overview
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Users</CardDescription>
            <CardTitle className="text-2xl">{analytics.totalUsers.toLocaleString()}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-sm text-green-600">
              <TrendingUp className="h-4 w-4" />
              +{analytics.weeklyGrowth}% this week
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Sessions Booked</CardDescription>
            <CardTitle className="text-2xl">{analytics.sessionsBooked}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              This month
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Forum Posts</CardDescription>
            <CardTitle className="text-2xl">{analytics.activeForumPosts}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <MessageSquare className="h-4 w-4" />
              Active discussions
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Mood Check-ins</CardDescription>
            <CardTitle className="text-2xl">{analytics.moodCheckins}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Users className="h-4 w-4" />
              This week
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Resources Accessed</CardDescription>
            <CardTitle className="text-2xl">{analytics.resourcesAccessed}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <TrendingUp className="h-4 w-4" />
              Total views
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Flagged Content</CardDescription>
            <CardTitle className="text-2xl text-destructive">{flaggedContent.length}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-sm text-destructive">
              <AlertTriangle className="h-4 w-4" />
              Needs review
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Mood Trends */}
      <Card>
        <CardHeader>
          <CardTitle>Weekly Mood Trends</CardTitle>
          <CardDescription>
            Average stress, anxiety, and mood levels across all users
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {moodTrends.map((week, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="font-medium">{week.week}</span>
                <span className="text-muted-foreground">
                  Stress: {week.stress}% | Anxiety: {week.anxiety}% | Mood: {week.mood}%
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span>Stress</span>
                    <span>{week.stress}%</span>
                  </div>
                  <Progress value={week.stress} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span>Anxiety</span>
                    <span>{week.anxiety}%</span>
                  </div>
                  <Progress value={week.anxiety} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span>Positive Mood</span>
                    <span>{week.mood}%</span>
                  </div>
                  <Progress value={week.mood} className="h-2" />
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Top Resources */}
        <Card>
          <CardHeader>
            <CardTitle>Most Accessed Resources</CardTitle>
            <CardDescription>Popular content this month</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {topResources.map((resource, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-sm">{resource.title}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-xs">{resource.category}</Badge>
                    <span className="text-xs text-muted-foreground">
                      {resource.views} views
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Flagged Content Review */}
        <Card>
          <CardHeader>
            <CardTitle className="text-destructive">Content Moderation Queue</CardTitle>
            <CardDescription>Posts flagged for review</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {flaggedContent.map((item) => (
              <div key={item.id} className="border rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <Badge variant="outline">{item.type}</Badge>
                  <Badge 
                    variant={item.status === "pending" ? "destructive" : "secondary"}
                    data-testid={`badge-status-${item.id}`}
                  >
                    {item.status}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground italic">
                  "{item.content}"
                </p>
                <div className="text-xs text-muted-foreground">
                  By: {item.author} • Reason: {item.flagReason}
                </div>
                {item.status === "pending" && (
                  <div className="flex gap-2 pt-2">
                    <Button size="sm" variant="outline" data-testid={`button-approve-${item.id}`}>
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Approve
                    </Button>
                    <Button size="sm" variant="destructive" data-testid={`button-remove-${item.id}`}>
                      Remove
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Action Suggestions */}
      <Card className="bg-accent/20">
        <CardHeader>
          <CardTitle>Recommended Actions</CardTitle>
          <CardDescription>Insights based on current trends</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
            <div>
              <p className="font-medium text-sm">Plan stress management workshop</p>
              <p className="text-xs text-muted-foreground">
                Stress levels are above average before midterm season
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
            <div>
              <p className="font-medium text-sm">Promote sleep resources</p>
              <p className="text-xs text-muted-foreground">
                Sleep-related content has high engagement rates
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
            <div>
              <p className="font-medium text-sm">Increase counselor availability</p>
              <p className="text-xs text-muted-foreground">
                Session booking demand is increasing by 12% weekly
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}