import { useState } from "react"
import { User, Globe, Bell, Shield, Download, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

interface ProfileSettings {
  nickname: string
  language: string
  notifications: {
    sessionReminders: boolean
    forumReplies: boolean
    weeklyCheckIn: boolean
  }
  privacy: {
    anonymousMode: boolean
    dataSharing: boolean
  }
}

// Mock user data - todo: remove mock functionality
const mockUserData = {
  joinDate: "2024-01-15",
  sessionsAttended: 3,
  forumPosts: 7,
  moodCheckins: 21,
  streakDays: 12
}

export default function ProfilePage() {
  const [settings, setSettings] = useState<ProfileSettings>({
    nickname: "StudentUser123",
    language: "english",
    notifications: {
      sessionReminders: true,
      forumReplies: false,
      weeklyCheckIn: true
    },
    privacy: {
      anonymousMode: true,
      dataSharing: false
    }
  })

  const [isEditing, setIsEditing] = useState(false)

  const handleSaveSettings = () => {
    // Mock save functionality - todo: replace with real API
    console.log("Saving settings:", settings)
    setIsEditing(false)
  }

  const handleExportData = () => {
    // Mock export functionality - todo: replace with real implementation
    console.log("Exporting user data...")
  }

  const handleDeleteAccount = () => {
    // Mock delete functionality - todo: replace with real implementation
    console.log("Account deletion requested")
  }

  return (
    <div className="p-6 space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Avatar className="h-16 w-16">
          <AvatarFallback className="text-lg">
            <User className="h-8 w-8" />
          </AvatarFallback>
        </Avatar>
        <div>
          <h1 className="text-3xl font-bold font-serif">{settings.nickname}</h1>
          <p className="text-muted-foreground">
            Member since {new Date(mockUserData.joinDate).toLocaleDateString()}
          </p>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{mockUserData.sessionsAttended}</div>
            <div className="text-sm text-muted-foreground">Sessions Attended</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{mockUserData.forumPosts}</div>
            <div className="text-sm text-muted-foreground">Forum Posts</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{mockUserData.moodCheckins}</div>
            <div className="text-sm text-muted-foreground">Mood Check-ins</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{mockUserData.streakDays}</div>
            <div className="text-sm text-muted-foreground">Day Streak</div>
          </CardContent>
        </Card>
      </div>

      {/* Profile Settings */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Profile Settings</CardTitle>
              <CardDescription>Manage your account preferences</CardDescription>
            </div>
            <Button
              variant={isEditing ? "default" : "outline"}
              onClick={isEditing ? handleSaveSettings : () => setIsEditing(true)}
              data-testid={isEditing ? "button-save-settings" : "button-edit-settings"}
            >
              {isEditing ? "Save Changes" : "Edit Settings"}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Basic Settings */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="nickname">Display Nickname</Label>
              <Input
                id="nickname"
                value={settings.nickname}
                onChange={(e) => setSettings(prev => ({ ...prev, nickname: e.target.value }))}
                disabled={!isEditing}
                data-testid="input-nickname"
              />
              <p className="text-xs text-muted-foreground">
                This is how you'll appear in the forum and chat
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="language">Language Preference</Label>
              <select
                id="language"
                value={settings.language}
                onChange={(e) => setSettings(prev => ({ ...prev, language: e.target.value }))}
                disabled={!isEditing}
                className="w-full p-2 border rounded-md bg-background"
                data-testid="select-language"
              >
                <option value="english">English</option>
                <option value="hindi">हिंदी (Hindi)</option>
              </select>
            </div>
          </div>

          <Separator />

          {/* Notifications */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Notification Preferences
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="session-reminders">Session Reminders</Label>
                  <p className="text-sm text-muted-foreground">
                    Get notified 24 hours before your counseling sessions
                  </p>
                </div>
                <Switch
                  id="session-reminders"
                  checked={settings.notifications.sessionReminders}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({
                      ...prev,
                      notifications: { ...prev.notifications, sessionReminders: checked }
                    }))
                  }
                  disabled={!isEditing}
                  data-testid="switch-session-reminders"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="forum-replies">Forum Replies</Label>
                  <p className="text-sm text-muted-foreground">
                    Get notified when someone replies to your posts
                  </p>
                </div>
                <Switch
                  id="forum-replies"
                  checked={settings.notifications.forumReplies}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({
                      ...prev,
                      notifications: { ...prev.notifications, forumReplies: checked }
                    }))
                  }
                  disabled={!isEditing}
                  data-testid="switch-forum-replies"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="weekly-checkin">Weekly Check-in</Label>
                  <p className="text-sm text-muted-foreground">
                    Gentle reminders to log your mood and feelings
                  </p>
                </div>
                <Switch
                  id="weekly-checkin"
                  checked={settings.notifications.weeklyCheckIn}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({
                      ...prev,
                      notifications: { ...prev.notifications, weeklyCheckIn: checked }
                    }))
                  }
                  disabled={!isEditing}
                  data-testid="switch-weekly-checkin"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Privacy Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Privacy & Security
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="anonymous-mode">Enhanced Anonymity</Label>
                  <p className="text-sm text-muted-foreground">
                    Extra privacy protections for all interactions
                  </p>
                </div>
                <Switch
                  id="anonymous-mode"
                  checked={settings.privacy.anonymousMode}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({
                      ...prev,
                      privacy: { ...prev.privacy, anonymousMode: checked }
                    }))
                  }
                  disabled={!isEditing}
                  data-testid="switch-anonymous-mode"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="data-sharing">Research Participation</Label>
                  <p className="text-sm text-muted-foreground">
                    Help improve mental health services with anonymous data
                  </p>
                </div>
                <Switch
                  id="data-sharing"
                  checked={settings.privacy.dataSharing}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({
                      ...prev,
                      privacy: { ...prev.privacy, dataSharing: checked }
                    }))
                  }
                  disabled={!isEditing}
                  data-testid="switch-data-sharing"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle>Data Management</CardTitle>
          <CardDescription>Control your personal data</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Export Your Data</h4>
              <p className="text-sm text-muted-foreground">
                Download a copy of your mood history and session data
              </p>
            </div>
            <Button 
              variant="outline" 
              onClick={handleExportData}
              data-testid="button-export-data"
            >
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-destructive">Delete Account</h4>
              <p className="text-sm text-muted-foreground">
                Permanently remove your account and all associated data
              </p>
            </div>
            <Button 
              variant="destructive" 
              onClick={handleDeleteAccount}
              data-testid="button-delete-account"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Support Info */}
      <Card className="bg-accent/20">
        <CardContent className="p-6">
          <h3 className="font-semibold mb-3">Need Help?</h3>
          <p className="text-sm text-muted-foreground mb-4">
            If you're experiencing technical issues or need support with the platform, 
            our team is here to help while maintaining your privacy.
          </p>
          <div className="flex gap-2">
            <Badge variant="outline">24/7 Crisis Support Available</Badge>
            <Badge variant="outline">Anonymous Help Desk</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}