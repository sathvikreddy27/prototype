# Overview

MindEase is a comprehensive mental health and wellness platform designed specifically for students. The application provides a private, stigma-free environment for mental health support through multiple channels: AI-powered chat assistance, confidential counseling booking, peer community forums, educational resources, and administrative oversight. Built as a full-stack web application, MindEase emphasizes empathy, privacy, and accessibility while maintaining professional credibility through its calming, wellness-focused design approach.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side is built using React 18 with TypeScript and Vite as the build tool. The application follows a modern component-based architecture with:

- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management and caching
- **UI Framework**: Custom component library built on Radix UI primitives with Tailwind CSS for styling
- **Design System**: Implements a comprehensive design system inspired by Headspace, Calm, and Discord, featuring calming color palettes, Inter/Source Serif Pro typography, and accessibility-focused components
- **Theme Support**: Light/dark mode theming with CSS custom properties

The architecture promotes component reusability through a well-structured component hierarchy with examples and UI primitives stored in separate directories.

## Backend Architecture
The server uses Express.js with TypeScript, implementing a RESTful API pattern:

- **Server Framework**: Express.js with middleware for request logging, JSON parsing, and error handling
- **AI Integration**: Google Gemini AI for mental health chat responses with crisis detection capabilities
- **Storage Layer**: Abstracted storage interface supporting both in-memory and database implementations
- **API Design**: RESTful endpoints with proper error handling and validation using Zod schemas

## Data Storage Solutions
The application uses a flexible storage architecture:

- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: Well-structured tables for users (anonymous nicknames), chat messages, counselor profiles, booking sessions, forum posts, and administrative oversight
- **Database Provider**: Neon serverless PostgreSQL for scalable cloud deployment
- **Session Management**: PostgreSQL-based session storage using connect-pg-simple

## Authentication and Privacy
Privacy-first approach with minimal data collection:

- **Anonymous Authentication**: Users identified by anonymous nicknames rather than personal information
- **Session Management**: Express sessions for maintaining user state without exposing personal data
- **Data Minimization**: Schema designed to collect only essential information for functionality
- **Crisis Detection**: Built-in safety mechanisms to detect and respond to crisis situations

## Component Architecture
The UI follows a hierarchical component structure:

- **Layout Components**: Sidebar navigation, theme providers, and responsive layout containers
- **Page Components**: Dedicated components for each major feature (chat, booking, resources, forum, dashboard)
- **UI Primitives**: Comprehensive set of accessible components built on Radix UI
- **Utility Components**: Crisis modals, toast notifications, and shared interactive elements

# External Dependencies

## AI and Machine Learning
- **Google Gemini AI**: Primary AI service for generating empathetic, evidence-based mental health responses with built-in crisis detection and safety protocols

## Database and Storage
- **Neon Database**: Serverless PostgreSQL provider for scalable, managed database hosting
- **Drizzle ORM**: Type-safe database toolkit providing schema definition, migrations, and query building

## UI and Design
- **Radix UI**: Comprehensive collection of accessible, unstyled UI primitives for building the component library
- **Tailwind CSS**: Utility-first CSS framework for consistent styling and responsive design
- **Lucide React**: Icon library providing consistent iconography throughout the application

## Development and Build Tools
- **Vite**: Fast build tool and development server with hot module replacement
- **TypeScript**: Static type checking for enhanced code quality and developer experience
- **TanStack Query**: Data fetching and caching library for efficient API state management

## Fonts and Typography
- **Google Fonts**: Inter (primary) and Source Serif Pro (headings) for accessible, professional typography that supports the wellness-focused design approach