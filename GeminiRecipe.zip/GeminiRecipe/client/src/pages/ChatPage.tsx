import { useState, useRef, useEffect } from "react"
import { Send, User, Bot, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { CrisisModal } from "@/components/CrisisModal"
import { useMutation } from "@tanstack/react-query"
import { apiRequest } from "@/lib/queryClient"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

interface ChatResponse {
  message: string
  isCrisis: boolean
  supportResources?: string[]
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Hello! I'm here to provide a safe space for you to share what's on your mind. Whether you're feeling stressed, anxious, or just need someone to listen, I'm here to support you. How are you feeling today?",
      role: "assistant",
      timestamp: new Date()
    }
  ])
  const [inputValue, setInputValue] = useState("")
  const [showCrisisModal, setShowCrisisModal] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const chatMutation = useMutation({
    mutationFn: async ({ message, conversationHistory }: { 
      message: string
      conversationHistory: { role: "user" | "assistant", content: string }[]
    }) => {
      const response = await apiRequest("POST", "/api/chat", { message, conversationHistory });
      const data = await response.json();
      return data as ChatResponse;
    }
  })

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async () => {
    if (!inputValue.trim() || chatMutation.isPending) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      role: "user",
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    const messageToSend = inputValue
    setInputValue("")

    try {
      // Prepare conversation history for context
      const conversationHistory = messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }))

      const response = await chatMutation.mutateAsync({
        message: messageToSend,
        conversationHistory
      })

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: response.message,
        role: "assistant",
        timestamp: new Date()
      }
      
      setMessages(prev => [...prev, aiResponse])
      
      if (response.isCrisis) {
        setShowCrisisModal(true)
      }
    } catch (error) {
      console.error("Chat error:", error)
      
      // Fallback response if API fails
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: "I'm experiencing some technical difficulties right now, but I want you to know that your feelings are valid and important. If you're in crisis, please reach out to a counselor or call a crisis helpline immediately.",
        role: "assistant",
        timestamp: new Date()
      }
      
      setMessages(prev => [...prev, errorResponse])
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="flex flex-col h-full max-h-screen">
      {/* Header */}
      <div className="p-4 border-b">
        <h1 className="text-2xl font-bold font-serif">AI Mental Health Support</h1>
        <p className="text-sm text-muted-foreground">
          A safe space for confidential support and guidance
        </p>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {message.role === "assistant" && (
              <Avatar className="h-8 w-8 mt-1">
                <AvatarFallback>
                  <Bot className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
            )}
            
            <Card className={`max-w-[80%] ${
              message.role === "user" 
                ? "bg-primary text-primary-foreground" 
                : "bg-card"
            }`}>
              <CardContent className="p-3">
                <p className="text-sm leading-relaxed">{message.content}</p>
                <p className={`text-xs mt-2 ${
                  message.role === "user" 
                    ? "text-primary-foreground/70" 
                    : "text-muted-foreground"
                }`}>
                  {message.timestamp.toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </p>
              </CardContent>
            </Card>

            {message.role === "user" && (
              <Avatar className="h-8 w-8 mt-1">
                <AvatarFallback>
                  <User className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
            )}
          </div>
        ))}

        {chatMutation.isPending && (
          <div className="flex gap-3 justify-start">
            <Avatar className="h-8 w-8 mt-1">
              <AvatarFallback>
                <Bot className="h-4 w-4" />
              </AvatarFallback>
            </Avatar>
            <Card className="bg-card">
              <CardContent className="p-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-100" />
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-200" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t">
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Share what's on your mind..."
            className="flex-1"
            data-testid="input-chat-message"
          />
          <Button 
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || chatMutation.isPending}
            data-testid="button-send-message"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex justify-center mt-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowCrisisModal(true)}
            className="text-destructive hover:text-destructive"
            data-testid="button-crisis-help"
          >
            <AlertTriangle className="h-4 w-4 mr-2" />
            Crisis Support
          </Button>
        </div>
      </div>

      <CrisisModal open={showCrisisModal} onOpenChange={setShowCrisisModal} />
    </div>
  )
}