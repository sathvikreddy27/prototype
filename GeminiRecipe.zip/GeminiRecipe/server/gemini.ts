import { GoogleGenAI } from "@google/genai";

// DON'T DELETE THIS COMMENT  
// Follow these instructions when using this blueprint:
// - Note that the newest Gemini model series is "gemini-2.5-flash" or gemini-2.5-pro"
//   - do not change this unless explicitly requested by the user

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface MentalHealthResponse {
  message: string;
  isCrisis: boolean;
  supportResources?: string[];
}

// Enhanced crisis detection with more comprehensive patterns
function detectCrisis(message: string): boolean {
  const crisisPatterns = [
    // Direct self-harm language
    /\b(suicide|kill myself|end my life|take my life|not worth living)\b/i,
    /\b(self.?harm|hurt myself|cutting|overdose)\b/i,
    /\b(hang myself|jump off|end it all|better off dead)\b/i,
    // Indirect crisis indicators
    /\b(no point|can't go on|hopeless|worthless|everyone.*better.*without)\b/i,
    /\b(planning to|thinking about).*\b(hurt|harm|kill|end)\b/i
  ];
  
  return crisisPatterns.some(pattern => pattern.test(message));
}

// Trim conversation history to prevent token overflow
function trimConversationHistory(history: ChatMessage[]): ChatMessage[] {
  const maxMessages = 6; // Keep last 6 messages for context
  return history.slice(-maxMessages);
}

export async function generateMentalHealthResponse(
  userMessage: string,
  conversationHistory: ChatMessage[] = []
): Promise<MentalHealthResponse> {
  // Input validation
  if (!userMessage || userMessage.trim().length === 0) {
    return {
      message: "I'm here to listen. Please share what's on your mind.",
      isCrisis: false
    };
  }

  if (userMessage.length > 2000) {
    return {
      message: "I want to give your message the attention it deserves. Could you share your thoughts in shorter messages so I can better support you?",
      isCrisis: false
    };
  }

  try {
    // Enhanced crisis detection
    const isCrisis = detectCrisis(userMessage);

    // Mental health focused system prompt with safety guidelines
    const systemPrompt = `You are a compassionate AI mental health support assistant for students. Your role is to:

1. Provide empathetic, non-judgmental responses
2. Offer evidence-based coping strategies and techniques
3. Validate feelings and normalize mental health struggles
4. Encourage professional help when appropriate
5. Never provide medical diagnoses or specific medical advice
6. Always maintain a warm, supportive tone
7. Focus on immediate coping strategies and emotional support

SAFETY GUIDELINES:
- If you detect crisis language, express immediate concern and encourage professional help
- Never provide harmful advice or instructions
- Always encourage seeking professional support for serious mental health concerns
- Keep responses supportive but never replace professional therapy

Response Guidelines:
- Keep responses concise but meaningful (2-3 sentences typically)
- Ask follow-up questions to encourage deeper sharing
- Suggest practical techniques like breathing exercises, grounding techniques
- Normalize seeking help and professional support
- Be culturally sensitive and inclusive

Remember: You're providing peer support and coping strategies, not therapy or medical advice.`;

    // Build conversation context with trimmed history
    let conversationContext = "";
    const trimmedHistory = trimConversationHistory(conversationHistory);
    if (trimmedHistory.length > 0) {
      conversationContext = "Previous conversation:\n" + 
        trimmedHistory.map(msg => 
          `${msg.role === "user" ? "Student" : "Assistant"}: ${msg.content}`
        ).join("\n") + "\n\n";
    }

    const prompt = conversationContext + `Student says: "${userMessage}"\n\nPlease respond with empathy and helpful mental health support.`;

    // Add timeout to prevent hanging requests
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout')), 30000); // 30 second timeout
    });

    const apiCall = ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        maxOutputTokens: 500, // Limit response length
        temperature: 0.7, // Balanced creativity vs consistency
      },
      contents: prompt,
    });

    const response = await Promise.race([apiCall, timeoutPromise]);
    let messageText = response.text?.trim() || "I'm here to listen and support you. Can you tell me more about what you're experiencing?";

    // Safety check on response length
    if (messageText.length > 1000) {
      messageText = messageText.substring(0, 1000) + "... I want to make sure I'm giving you focused support. How are you feeling right now?";
    }

    const supportResources = isCrisis ? [
      "National Suicide Prevention Lifeline: 988",
      "Crisis Text Line: Text HOME to 741741",
      "International Association for Suicide Prevention: https://www.iasp.info/resources/Crisis_Centres/",
      "Campus counseling services are available 24/7"
    ] : undefined;

    return {
      message: messageText,
      isCrisis,
      supportResources
    };

  } catch (error) {
    console.error("Gemini API Error:", {
      message: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    });
    
    // Structured fallback response for API failures
    return {
      message: "I'm experiencing some technical difficulties right now, but I want you to know that your feelings are valid and important. If you're in crisis, please reach out to a counselor or call a crisis helpline immediately.",
      isCrisis: false
    };
  }
}