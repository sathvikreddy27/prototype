import { useState } from "react"
import { ArrowRight, Shield, Heart, Users, MessageSquare } from "lucide-react"
import { Link } from "wouter"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CrisisModal } from "@/components/CrisisModal"
import heroImage from "@assets/generated_images/Calming_hero_background_fd62fe9c.png"

const features = [
  {
    icon: MessageSquare,
    title: "AI-Guided Support",
    description: "Chat with our empathetic AI for immediate mental health first-aid and coping strategies."
  },
  {
    icon: Shield,
    title: "Complete Privacy",
    description: "Anonymous sessions with end-to-end privacy protection. Your wellbeing, your terms."
  },
  {
    icon: Heart,
    title: "Professional Care",
    description: "Book confidential sessions with qualified counselors when you need human support."
  },
  {
    icon: Users,
    title: "Peer Community",
    description: "Connect with others who understand, in a safe and moderated environment."
  }
]

export default function LandingPage() {
  const [showCrisisModal, setShowCrisisModal] = useState(false)

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative py-20 px-6 text-center bg-gradient-to-br from-background to-accent/10"
        style={{
          backgroundImage: `linear-gradient(rgba(220, 220, 240, 0.7), rgba(220, 220, 240, 0.7)), url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="container mx-auto max-w-4xl">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-primary font-serif">
            Your Private Mental Wellness Space
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-muted-foreground max-w-2xl mx-auto">
            A safe, stigma-free platform providing students with AI-guided support, 
            confidential counseling, and peer community.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" asChild data-testid="button-get-started">
              <Link href="/chat">
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => setShowCrisisModal(true)}
              data-testid="button-crisis-support"
            >
              Need Crisis Support?
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-6">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12 font-serif">
            Mental Health Support That Works For You
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover-elevate">
                <CardHeader>
                  <feature.icon className="h-12 w-12 mx-auto text-primary mb-4" />
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-6 bg-accent/20">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-3xl font-bold mb-6 font-serif">
            Taking care of yourself matters
          </h2>
          <p className="text-lg mb-8 text-muted-foreground">
            Join thousands of students who've found support, community, and healing through MindEase.
          </p>
          <Button size="lg" asChild data-testid="button-start-journey">
            <Link href="/chat">
              Start Your Wellness Journey
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © 2024 MindEase. A safe space for mental wellness.
            </p>
            <p className="text-xs text-muted-foreground">
              This platform is not a replacement for professional therapy.
            </p>
          </div>
        </div>
      </footer>

      <CrisisModal open={showCrisisModal} onOpenChange={setShowCrisisModal} />
    </div>
  )
}