import DashboardPage from '../../pages/DashboardPage'

export default function DashboardPageExample() {
  return (
    <div className="max-h-96 overflow-y-auto">
      <DashboardPage />
    </div>
  )
}