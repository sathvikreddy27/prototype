import ForumPage from '../../pages/ForumPage'

export default function ForumPageExample() {
  return (
    <div className="max-h-96 overflow-y-auto">
      <ForumPage />
    </div>
  )
}