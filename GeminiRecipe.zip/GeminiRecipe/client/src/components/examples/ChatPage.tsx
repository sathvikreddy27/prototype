import ChatPage from '../../pages/ChatPage'

export default function ChatPageExample() {
  return (
    <div className="h-96 border rounded-lg overflow-hidden">
      <ChatPage />
    </div>
  )
}