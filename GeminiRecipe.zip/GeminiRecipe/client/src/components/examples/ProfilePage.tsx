import ProfilePage from '../../pages/ProfilePage'

export default function ProfilePageExample() {
  return (
    <div className="max-h-96 overflow-y-auto">
      <ProfilePage />
    </div>
  )
}